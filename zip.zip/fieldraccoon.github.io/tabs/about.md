---
title: About

# The About page
# v2.0
# https://github.com/cotes2020/jekyll-theme-chirpy
# © 2017-2019 Cotes Chung
# MIT License
---

# About me

### I am a young student from the united Kingdom interested in Cyber Security.

### I take part in ctfs with my team `The WinRaRs` -- [CTF time](https://ctftime.org/team/113086)


My hack the box profile -- [https://www.hackthebox.eu/home/users/profile/246314](https://www.hackthebox.eu/home/users/profile/246314)
